# TikTok-Live-Chat-Overlay
Displays only the chat for TikTok Live while keeping the stream running in the background.

# NOTE
This extension is provided as-is. While its functionality is minimal, any issues or malfunctions are your responsibility. 